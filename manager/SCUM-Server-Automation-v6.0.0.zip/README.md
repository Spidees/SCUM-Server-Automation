# SCUM Server Automation

Thanks for downloading **SCUM Server Automation** — one app that installs, runs, updates,
backs up and monitors your SCUM dedicated server, with a Discord bot, a web command panel
and a public stats site for your players.

## What's in this folder

- `SCUM-Server-Automation.exe` — the manager (run this). **Everything is inside it** — the
  server tools and the bundled plugins (UE4SS + SSA Bridge) are all self-contained.
- `LICENSE.txt` — the license this software is provided under
- `README.md` — this file

Everything else (`config\`, `data\`, `backups\`, `server\`, `steamcmd\`, `plugins\`, …) is
created automatically the first time you run it.

## Requirements

- **Windows 10 / 11 or Windows Server** — the same machine that will run your SCUM server
- **Administrator rights** — the app asks for them automatically (needed to manage the server)

That's it. SteamCMD, the SCUM server files and the required Microsoft runtimes (Visual C++
and DirectX) are downloaded and installed **for you** on first run.

## Get started

1. Put the exe and the `assets\` folder together in an empty folder, e.g. `C:\SCUM`.
2. Double-click **`SCUM-Server-Automation.exe`** and accept the administrator prompt.
3. Your browser opens the setup wizard (or go to `http://localhost:8080/admin/`). Pick a
   language, set an admin password, confirm the folders — the app installs the SCUM server.
4. Full step-by-step guide: **https://scumsa.com/guide.php**

## Updates

The manager checks for new versions itself. When one is available you'll see it in the panel:

- **Premium:** install the new version in one click (or turn on automatic updates).
- **Free:** download the new build from **https://scumsa.com** and replace the exe — your
  `config\` and `data\` are kept. Plugins are inside the exe, so nothing else to swap.

Your settings and data live next to the exe, so updating never loses them.

## Premium

The manager is free. **Premium** (from €10/month) adds the branded public Field Console,
the live map with in-game admin control, Discord ↔ game chat relay, plugins, the complete
item database and one-click updates. Manage it at **https://scumsa.com**.

## Who publishes it

`SCUM-Server-Automation.exe` is code-signed by **Martin Zámečník**, and that is the publisher
Windows names on the administrator prompt. If it names anyone else, or says *Unknown publisher*,
the file is not one we shipped: download it again from **https://scumsa.com**.

## Need help?

- Setup guide & FAQ: **https://scumsa.com/guide.php**
- Community: **https://scumsa.com/discord**
