================================================================================
  SSA REPORTER v1.0.1
  Puts your SCUM server in the scumsa.com server browser, live
  https://scumsa.com/docs/owners/reporter
================================================================================

Plain text on purpose: this file is opened on a game host, in Notepad.


--------------------------------------------------------------------------------
WHAT THIS IS
--------------------------------------------------------------------------------

The SSA Reporter is a small mod that runs INSIDE your SCUM dedicated server and
tells the scumsa.com server browser what your server is doing right now: its
name, how many players are on, the game version, the in-game time and how long
it has been up. The browser then shows your server as checked live.

That is ALL it does. It has no commands, no admin rights, no open port and no
second program. It reads a handful of numbers and sends them once a minute.

You do not need it if your server already runs the SSA Bridge (it has the same
report built in, module "report") or SCUM Server Automation (the manager).
Run ONE of them. If the SSA Bridge is installed and enabled, the Reporter does
not start and says so in its log.

It works on a rented server too, as long as you can upload files into the
server's folder and restart it.


--------------------------------------------------------------------------------
WHAT IS IN THIS ARCHIVE
--------------------------------------------------------------------------------

  SSAReporter-README.txt                  this file
  LICENSE-SSAReporter.txt                 the licence this mod is provided under
  LICENSE-UE4SS.txt                       the UE4SS licence (MIT)

  dwmapi.dll                              UE4SS - the loader the game picks up
  UE4SS.dll                               UE4SS - the runtime
  UE4SS-settings.ini                      UE4SS - settings, tuned for a server

  Mods\SSAReporter\dlls\main.dll          the Reporter itself
  Mods\SSAReporter\enabled.txt            its presence is what starts the mod
  Mods\SSAReporter\SSAReporter.config.example.json
                                          a reference copy of the settings file.
                                          Nothing reads it.

Everything is laid out relative to your server's SCUM\Binaries\Win64 folder.


--------------------------------------------------------------------------------
INSTALL
--------------------------------------------------------------------------------

1. On scumsa.com, open your account page and find your server. Press
   "Reporter token" and copy the token it shows you. It is shown once.

2. STOP the server.

3. Extract this archive into:

       <your server>\SCUM\Binaries\Win64\

   If UE4SS is already there (another mod uses it), keep your own UE4SS files
   and copy only the Mods\SSAReporter folder.

4. START the server once and stop it again. The Reporter writes its settings
   file on the first start:

       <your server>\SCUM\Binaries\Win64\Mods\SSAReporter\SSAReporter.config.json

   (You can also create it yourself from SSAReporter.config.example.json.)

5. Open that file in Notepad and paste the token between the quotes:

       {
         "enabled": true,
         "token": "paste-your-token-here",
         "intervalSec": 60
       }

   Save it. The Reporter notices the change within ten seconds; no restart is
   needed, but a restart does no harm.

6. Check that it works: the log beside the settings file,

       <your server>\SCUM\Binaries\Win64\Mods\SSAReporter\SSAReporter.log

   says "server report: accepted by scumsa.com" within a minute or two, and
   your server's row in the browser shows it as checked live.


--------------------------------------------------------------------------------
THE SETTINGS
--------------------------------------------------------------------------------

  enabled      true or false. false stops the reports without uninstalling.
  token        the token from your scumsa.com account page. Keep it private:
               anyone who has it can report for your server. Revoke it on the
               account page and paste a new one if it leaks.
  intervalSec  how often to report when nothing changes, 30 to 600 seconds.
               The site may ask for a different pace, and that wins.

The file is never overwritten. If it cannot be read (a missing quote, a
trailing comma, an empty file), the Reporter leaves it exactly as it is, sends
nothing and says why in its log.

UPGRADE-SAFE: SSAReporter.config.json is NOT in this archive, so extracting a
new version over an old one keeps your token.


--------------------------------------------------------------------------------
WHAT IT SENDS, AND WHAT IT NEVER SENDS
--------------------------------------------------------------------------------

Sent to https://scumsa.com once a minute, and two seconds after anyone joins or
leaves:

  * the server name, as the game holds it
  * the game port and query port, when they are on the server's command line
  * the game version (for example 1.3.4.2.161892)
  * players online and the player limit
  * the in-game time of day
  * how long the server process has been running
  * the map
  * the token, the Reporter's version and the UE4SS version

A value the Reporter cannot read is left out, never sent as zero.

NEVER sent: player names, Steam IDs, chat, anything from the save, anything
about your machine. The token is never written into any log.

The connection is HTTPS. If scumsa.com cannot be reached, the Reporter waits
(one minute, then longer, up to five minutes) and writes at most one line about
it every five minutes. Your server is not affected either way.


--------------------------------------------------------------------------------
REMOVE IT
--------------------------------------------------------------------------------

Stop the server and delete Mods\SSAReporter. Keep dwmapi.dll, UE4SS.dll and
UE4SS-settings.ini if another mod uses UE4SS; otherwise delete them too.


--------------------------------------------------------------------------------
LICENCES
--------------------------------------------------------------------------------

The Reporter is provided under LICENSE-SSAReporter.txt. UE4SS is MIT-licensed
(LICENSE-UE4SS.txt); its copyright and permission notice travel with every copy.
