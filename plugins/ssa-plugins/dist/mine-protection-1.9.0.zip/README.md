# Mine Protection

Punishes players who **arm a mine or trap outside their own or their squad's flag area**. The first
offences earn a chat **warning**; after that the placer is **teleported onto their own armed mine**.
Optionally it also **removes the mines a fallen flag leaves behind** when no new flag is built in time.

## How it works
- Every few seconds the plugin reads the manager's **world scan** for placed, **armed** mines and traps
  of the watched types, and **who armed each one**.
- A mine is legal when it sits inside the **flag area of any base owned by the placer or a squadmate**.
  A squad member arming inside a teammate's base is never punished.
- **Before a teleport, the running game is asked** whether the mine is still armed and who is in the
  placer's squad right now. A mine defused since the last save, or a squadmate who joined since then,
  calls the punishment off. These checks can only cancel an offence, never create one.
- **Escalation:** the first offences per player are a warning, then the teleport. The teleport runs
  through the placer, so it does not depend on name or Steam ID targeting.
- **It never punishes on a guess.** When the game database cannot say whether a mine is inside a flag,
  the mine is left alone and checked again on the next scan.
- **Offline placers** are dealt with the moment they reconnect: the bridge's join announcement counts
  them as online and starts a scan at once, without waiting for the next save.
- **State survives restarts:** handled mines, offence counts and the action history are saved, so a
  restart never punishes the same mine twice. Mines that were already placed when the plugin first
  ran are never punished.
- **Fallen flags (off until you switch it on):** when a flag disappears from the world, a **timer**
  starts (10 minutes by default). If no new flag stands in the **original flag area** when it runs
  out, every placed mine inside that area is removed through the bridge, one by one, and the log
  gets one line per area with the counts.
- **Only the same owner or their squad keeps the mines** with a new flag, by default. A raider who
  builds a flag on the ruins does not keep the old owner's mines alive inside their base.
- **A mine counts as removed only when the game confirms it.** A refusal is logged in the bridge's
  own words and tried again until the grace period runs out. Timers survive a manager restart.

## Requirements
- The **SSA Bridge** plugin, for the teleport and the chat message.
- Two bridge modules are optional and recommended, because they let the plugin check the running game
  instead of the last save. The plugin's card on the **Plugins** page lists them and offers to switch
  them on:
  - **Live inventories**: *Read live inventories*, which confirms a mine is still armed.
  - **Live squads**: *Read live squads, and allow the changes below* and *Include the member list*,
    which confirm the placer's current squad.
- For **fallen-flag removal**: *Destroy an item* in the **Live inventories** module. To clear an
  area with nobody near it, also the **Far from players** module (*Work far from players*).
- Manager **6.0.0+**.

## Configuration
Everything is configured from the plugin's **admin tab** (🛡️ Mine Protection):

- **Watched mines & traps**: a picker with an icon per type and how many are placed and armed right
  now. Quick buttons: *Explosives only* (every explosive, C4 included), *Select all*, *Clear*. The
  default selection is the explosives without C4, because C4 is a raiding tool.
- **When a violation is found**: teleport onto their mine, or warn only.
- **Warnings before action**: how many warnings a player gets first (default 1, 0 acts at once).
- **Extra margin around flag (m)**: tolerance beyond the flag area (default 0).
- **Scan interval (s)**: how often to scan (default 6). Applies as soon as you save.
- **Only act while the placer is online** (on by default).
- **In-game messages**: the chat channel, the warning message and the penalty message.
- **Every player's language**: each message has a tab per language, and every player reads the
  one for the language they chose with `/lang` in game, on the Field Console or on Discord. An
  empty tab sends the default text.
- **Mines of a fallen flag**: the on/off switch (off by default), the delay before removal, how long
  to keep trying after it, whether every mine and trap or only the watched types are removed, whose
  new flag keeps the mines, loading an empty area, an owner alert, and a chat announcement in every
  player's language. The list below it shows each fallen flag, its state and a *Keep mines* button.
- **Exemptions**: players who are never punished. Type a Steam ID or pick an online player.
- **Placed mines**: every watched mine in the server's last save, who armed it, where, and its status.
- **Recent actions**: every warning and teleport, with *Reset warnings* and *Clear history*.

## Good to know
- **Forgive one player** with the *Forgive* button on their row in the mines table. *Reset warnings*
  clears everybody.
- **A warning counts only once it arrives.** If the player is not online to receive it, the mine is
  checked again later instead of counting as their warning.
- *Armed state unknown* and *Flag unknown* in the mines table mean the plugin could not tell, and it
  does nothing about those mines until it can.
- The placer is whoever **armed** the mine, not whoever crafted or placed it.
- Everything can be configured with the server stopped; only the live lists need it running.
- **A mine can only be removed while the game has its area loaded**, which means a player nearby or
  the bridge's *Work far from players* visitor. Without either, removal waits and says so.
- A flag is seen as fallen when the **server's save** (or the game's own flag log) no longer has it,
  so the timer starts up to one autosave after the flag really fell.
- Switching fallen-flag removal on only starts watching: flags that fell before that are left alone.
- **A new install already speaks every player's language.** A message you have not changed goes out
  in the plugin's own translation; once you edit it, players read your wording. On a manager without
  per-language chat, everyone gets the one text.

---

*Part of [SCUM Server Automation](https://scumsa.com) — the all-in-one SCUM dedicated server manager. Get the manager, browse every plugin and read the docs at [scumsa.com](https://scumsa.com).*
