# More Chat Messages

Tell your players what is happening, **in the game's own chat**. Kills, players joining and leaving, cargo drops, game events opening and starting, secret and abandoned bunkers opening, and bases being raided — **each one switched on separately**, sent to **whichever chat channel you choose**, and **worded however you like**. Everything ships **off**, so your server says nothing new until you decide it should.

## How it works

- **Every announcement is its own switch.** Kills, joins, leaves, cargo drops, game events, secret bunkers, abandoned bunkers and raids are all independent — turn on the two you want and leave the rest silent.
- **Game events get four moments**: sign-ups opening, each person signing up, the start and the end. The sign-up count comes free; naming the person needs **"Who is in the event"** in the bridge, because that costs the game a call per participant.
- **You pick the channel.** Every announcement goes to **local, global, squad, admin or server**, chosen per announcement. A kill feed in global and raid alerts in admin is a perfectly ordinary setup.
- **You write the words.** Each message is a text box with **placeholders** — `{killer}`, `{victim}`, `{weapon}`, `{distance}`, `{name}`, `{sector}`, `{owner}` — listed under the box you are typing in.
- **Kills come from the manager's own kill feed**, so a weapon and an actor are named the way the game names them rather than as a blueprint class. A death the game could not attribute to anybody gets its **own wording**, and so does a suicide.
- **Cargo is asked for, not waited for.** A drop exists only in the running game, so the plugin **asks the SSA Bridge on a timer and announces the difference** — while it is still in the air, when it lands, and when it is gone.
- **Bunkers come from the server's own log**, so they need no bridge. The two kinds are separate switches because they are separate things: the **abandoned** ones open and lock on their own rota, and a **secret** one only ever opens because a player used a key card on it.

## Requirements

- The **SSA Bridge**, for the cargo and game-event announcements. Kills, joins, leaves, bunkers and raids work without it.
- In the bridge's **World events** module: `enabled`, `cargo` and `events`. The plugin's card offers to switch them on for you. `players` is optional and is what puts a name on each sign-up.
- Manager **5.13.0** or newer, and **5.14.8** for the secret-bunker announcement — on an older one that card stays quiet and everything else works.

## Configuration

Everything is configured from the plugin's **admin tab** (💬 Chat Messages):

- Every setting can be written **with the server stopped** and goes live the moment it starts. Only the counters wait for a running game.
- Each card has the same three questions: **is it on**, **which chat**, and **what does it say**.
- The recent list shows what was actually said, and says when nobody was online to hear it.

## Good to know

- **Everything is off out of the box.** Installing this plugin changes nothing until you switch an announcement on.
- **Naming a raided base's owner is off on purpose.** On a PVP server, announcing whose base is being hit and where is a raid advertisement rather than news. Turn it on if your server wants it.
- **A bridge that is not answering is not an empty island.** If the cargo poll fails, the plugin says nothing rather than announcing every crate as gone — and the screen tells you which of the two it is.
- **Each announcement has its own interval, and only four of them poll at all.** Kills, joins, leaves and raids are announced the moment the manager reads them out of the log. Cargo drops and game events ask the **SSA Bridge**, and one ask walks every object in the running game, so those two are the ones worth slowing down rather than speeding up. Bunkers poll the manager's own parsed log and cost the game nothing. Two cards falling due together share one ask.
- **The game logs nothing at all about events.** Every other announcement here can fall back to the server's own log; this one cannot, so with no bridge the event section simply stays quiet.
- **A kill line has no sector.** The kill log records where the killer and the victim were, but the manager hands that on as a sentence rather than as a position, so there is nothing to turn into a sector. The other announcements all have one.
- **One cargo drop is one announcement, even though a crate has two positions.** The game reports where a crate is *going* and where it *is*, and which of the two you get changes while it falls. The plugin follows the crate itself rather than the numbers, so a drop is announced once however the readings move.
- **A secret bunker has no position and no closing line.** The game gives it neither, so `{x}` and `{y}` stay empty in those two messages and the close is announced when its key card window runs out.
- **Nothing is announced from the first poll after a restart.** The plugin has to see the world twice before it can tell what changed, so it will not announce every open bunker as newly open when the server comes up.
- **Chat goes to whoever is online.** A message sent while the server is empty reaches nobody and is not resent.

---

*Part of [SCUM Server Automation](https://scumsa.com) — the all-in-one SCUM dedicated server manager. Get the manager, browse every plugin and read the docs at [scumsa.com](https://scumsa.com).*
