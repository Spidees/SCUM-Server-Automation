================================================================================
  SSA BRIDGE v2.20.0
  The in-game control mod for a SCUM dedicated server
  https://scumsa.com/bridge.php
================================================================================

Plain text on purpose: this file is opened on a game host, in Notepad. The same
information, with links, is at https://scumsa.com/docs/owners/bridge


--------------------------------------------------------------------------------
WHAT THIS IS
--------------------------------------------------------------------------------

The SSA Bridge is a mod that runs INSIDE your SCUM dedicated server process and
lets you read and change the running game: admin commands, item and vehicle
spawns, teleports, chat, live player and world state, kills, raids, and much
more, across 43 modules.

It is FREE and it is COMPLETE. Every module, every command and every read works
with the files in this archive alone. There is nothing to unlock, nothing that
expires, and nothing held back for a paid tier. See "FREE AND LICENSED" below
for the one thing a licence changes.

You do NOT need SCUM Server Automation (the manager) to run it. If you DO run
the manager, stop here: the manager carries its own copy of the bridge, deploys
it and configures it from the admin panel. Installing this archive by hand on a
machine the manager also manages makes the two disagree about what is installed.
See "IF YOU LATER INSTALL THE MANAGER" at the end.

What you need:

  * A Windows SCUM dedicated server whose FILES you control. A host that only
    gives you a settings form cannot run this.
  * The ability to STOP and START it. The game holds these files open while it
    runs, so they can only be put in place with the server down.

No account, no database, no open ports. Out of the box the bridge listens on
127.0.0.1 and talks to nobody.


--------------------------------------------------------------------------------
WHAT IS IN THIS ARCHIVE
--------------------------------------------------------------------------------

  SSABridge-README.txt                    this file
  LICENSE-SSABridge.txt                   the licence this mod is provided under
  LICENSE-UE4SS.txt                       the UE4SS licence (MIT) - see below

  dwmapi.dll                              UE4SS - the loader the game picks up
  UE4SS.dll                               UE4SS - the runtime
  UE4SS-settings.ini                      UE4SS - settings, tuned for a server

  Mods\SSABridge\dlls\main.dll            the bridge itself
  Mods\SSABridge\enabled.txt              its presence is what starts the mod
  Mods\SSABridge\SSABridge.config.example.json
                                          a reference copy of the bridge's own
                                          settings file. Nothing reads it - see
                                          "THE TWO CONFIG FILES" below.

Everything is laid out relative to your server's SCUM\Binaries\Win64 folder, so
extracting the archive there puts every file exactly where it belongs.


--------------------------------------------------------------------------------
INSTALL
--------------------------------------------------------------------------------

1. STOP the server. Copying over a running game's files either fails outright or
   leaves you half installed.

2. Extract this archive into:

       <your server>\SCUM\Binaries\Win64\

   You should end up with:

       <your server>\SCUM\Binaries\Win64\
       |-- dwmapi.dll
       |-- UE4SS.dll
       |-- UE4SS-settings.ini
       `-- Mods\
           `-- SSABridge\
               |-- dlls\main.dll
               |-- enabled.txt
               `-- SSABridge.config.example.json

   Nothing is written outside that folder. There is no installer and nothing
   touches the registry.

3. START the server.

4. Nothing will happen. That is correct - see "EVERYTHING SHIPS SWITCHED OFF".


--------------------------------------------------------------------------------
DID IT LOAD?
--------------------------------------------------------------------------------

Look in SCUM\Binaries\Win64\Mods\SSABridge\ after the server has started. The
bridge creates these itself, and their presence is the answer:

  SSABridge.log             written immediately, first line
                            "==== SSA Bridge v2.20.0 loaded ===="
  SSABridge.status.json     written once it is listening. Contains the port it
                            actually bound and this machine's machineId.
  modules.json              every module and every setting, at its default
  modules-reference.txt     the manual: every setting, what it does, what it
                            costs, and its legal values
  modules-recommended.json  a safe set to start from (see below)

If NONE of those appear, the mod was not started. UE4SS writes UE4SS.log in
SCUM\Binaries\Win64\ and it normally says why in a single line. The usual causes:

  * The files went to the wrong folder. dwmapi.dll must sit next to SCUMServer.exe
    in SCUM\Binaries\Win64\, NOT in the server root.
  * enabled.txt was lost in extraction. Without it UE4SS does not start the mod.
    It is an empty file; you can simply create it again.
  * The server was not actually restarted.


--------------------------------------------------------------------------------
EVERYTHING SHIPS SWITCHED OFF
--------------------------------------------------------------------------------

All 43 modules are OFF by default, and most things that CHANGE the game are off
a second time behind their own switch inside a module. Installing the bridge
therefore does nothing to your server until you decide it should. "Nothing
happened" is the expected first run, not a fault.

That is deliberate and it does make a dull first day, so the bridge writes a
starting point for you:

       Mods\SSABridge\modules-recommended.json

It is the same complete file as modules.json with a safe set already switched
on: every setting it enables is a READ, or a write that only puts text on a
screen. Nothing in it changes your world, moves anything, or costs the game
thread work on a timer.

To use it:

   1. STOP the server.
   2. Copy modules-recommended.json OVER modules.json.
   3. START the server.

Nothing applies it for you, and the bridge never reads it. Copying it across is
the decision, and it is yours.

To go further, open modules-reference.txt next to it. It is generated by the
bridge itself on every start, from the same descriptions the manager's admin
panel draws its screens from, so it always describes the build you are actually
running. Every setting is listed with its label, type, legal values, default and
an explanation - including what switching it on COSTS.

Edit modules.json, restart the server. The bridge reads it only at start.

If modules.json will not parse, the bridge leaves your file exactly as it is,
runs on defaults and says so in its log. It never rewrites a file you edited.


--------------------------------------------------------------------------------
THE TWO CONFIG FILES
--------------------------------------------------------------------------------

modules.json is what the bridge DOES. SSABridge.config.json is how the bridge
RUNS: the port, the bind address, the remote-control token, the rate limits.

The bridge writes SSABridge.config.json itself, with sane defaults, the first
time it starts. It is not in this archive on purpose - see "UPDATING" below.

SSABridge.config.example.json IS in this archive. It is a reference: a complete
file with every key the current build understands, including a few the generated
one leaves out. Nothing reads it. Copy values out of it into your real
SSABridge.config.json if you want them.

The important ones:

  "host"   defaults to 127.0.0.1 - local only, which is what you want unless
           you are driving the bridge from your own tooling on another machine.
  "port"   defaults to 27717.
  "token"  a shared secret required from REMOTE clients. It is EMPTY out of the
           box, which is safe because nothing remote can connect anyway.

If you set "host" to 0.0.0.0 you MUST also set a long random "token", and you
should put that port behind a firewall. It is a plain TCP port with a shared
secret; it is not TLS and it is not meant to face the internet.


--------------------------------------------------------------------------------
UPDATING
--------------------------------------------------------------------------------

This archive is UPGRADE-SAFE. Stop the server, extract the new archive over the
old one, start it. Nothing you have configured is lost, because none of the
files you configure are in the archive:

  * modules.json is never in the archive. Your settings survive.
  * SSABridge.config.json is never in the archive. Your port, bind address,
    remote token and rate limits survive.
  * SSABridge.license is never in the archive. Your licence survives.

Two files ARE replaced by an update, and both are ours rather than yours:
main.dll, which is the point of the update, and UE4SS-settings.ini. If you
edited UE4SS-settings.ini, keep a copy before you extract.

modules-reference.txt, modules-recommended.json and SSABridge.config.example.json
are rewritten to describe the new build, which is what they are for.


--------------------------------------------------------------------------------
FREE AND LICENSED
--------------------------------------------------------------------------------

Without a licence, the bridge introduces itself. A couple of seconds after each
player joins, it sends THAT player one line in chat naming the bridge and
scumsa.com.

With a licence, that line is not sent. That is the entire difference. No feature
is gated behind it, no limit lifts, no timer runs out. A server with no licence
file has all 43 modules and every command available to it.

If a licence lapses - expired, deleted, a week with no internet - nothing stops
working. The line simply comes back.

Getting one: a licence is bound to ONE machine and comes from your scumsa
account, on a server your plan covers.

   1. Start the server once with the bridge installed. It writes
      Mods\SSABridge\SSABridge.status.json, which contains a "machineId".
   2. On https://scumsa.com/account.php open "Running the bridge without the
      manager?" under that server's card, paste the machineId, and download
      SSABridge.license.
   3. Put that file in Mods\SSABridge\, next to main.dll's folder. The bridge
      picks it up on its own - no restart needed.

It is valid for 30 days on that machine. Come back for a new one when it runs
out; if you forget, see above.

ONE THING A LICENCE DOES NOT COVER. A bridge whose main.dll was MODIFIED after
it was signed refuses commands outright - licence or no licence, free or paid.
That check is not about subscriptions: it means the file is not the one we
shipped. https://scumsa.com/bridge.php publishes the SHA-256 of main.dll itself,
not only of the archive, so you can check the file that is actually on your
server. If it does not match, download a fresh copy rather than hunting for a
licence problem.


--------------------------------------------------------------------------------
IF YOU LATER INSTALL THE MANAGER
--------------------------------------------------------------------------------

SCUM Server Automation deploys and updates its own copy of the bridge and drives
all 43 modules from a web panel - switches, presets, live data, a clickable map.

If you install it on a server where you put the bridge in by hand: DELETE the
hand-installed Mods\SSABridge folder first and let the manager deploy its own.
enabled.txt starts the mod regardless of what the panel's switch says, so the
two would disagree, and the panel is the half that would look broken.

https://scumsa.com


--------------------------------------------------------------------------------
LICENCES AND CREDITS
--------------------------------------------------------------------------------

The SSA Bridge (Mods\SSABridge\dlls\main.dll) is part of SCUM Server Automation,
Copyright (c) 2025-2026 Spidees. It is provided under the licence in
LICENSE-SSABridge.txt. Read it: it permits you to run this on servers you
operate, including commercially, and it does not permit you to redistribute it.

UE4SS (dwmapi.dll, UE4SS.dll, UE4SS-settings.ini) is a separate, third-party
open-source project - RE-UE4SS, Copyright (c) 2022 Narknon and contributors -
redistributed here under the MIT License, reproduced in full in
LICENSE-UE4SS.txt. It is not ours, we do not charge for it, and its source and
its own releases are at:

       https://github.com/UE4SS-RE/RE-UE4SS
       https://docs.ue4ss.com

SCUM is a trademark of its respective owners. This project is not affiliated
with Gamepires or SCUM.


--------------------------------------------------------------------------------
HELP
--------------------------------------------------------------------------------

  Install guide      https://scumsa.com/docs/owners/bridge
  Module reference   https://scumsa.com/docs/dev/ssa-bridge
  The manager        https://scumsa.com
  Community          https://scumsa.com/discord
